@xvm.export('math', 'pow')
def pow(a, n):
    return a ** n
