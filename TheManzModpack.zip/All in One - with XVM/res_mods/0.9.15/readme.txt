This folder is used for World of Tanks modifiers (mods).  
