

Requirments:
  
 - You need to have XVM installed to get the hitlog working.
   XVM also has to be set to accept modifcations. 

-----------------------------

How to install:

 - Copy paste the res_mods folder over the res_mods folder in your world of Tanks directory.
	! - You may have to manually copy paste the hitlog into the right config folder you're using.
	    These can be found in the "res_mods/configs/xvm/default" folder.

 - Copy the res folder over the one in your world of tanks directory (contains the audio files for ammorack & fires)

-----------------------------




Have fun!